# CSC275-Game-Project
WIZARD OF THE VALLEY

- Our game is called Wizard of the Valley. You play as a Wizard who is trying to collect ingredients for potions
  as a way to get rid of the enemies in the Valley.
  
  HOW TO PLAY:
  - Use WASD to move left and right and jump, and SPACEBAR to shoot.
  - Go back and forth on the screen to to collect 3 different items to access the next level.
  - Kill 5 slimes to get a jump boost, 3 ghosts to get a fall powerup, and 2 bats to get a speed boost (subject to change)
  - Game is over at the end of level 3 once you have collected all of the items.
   
  CREDITS:
  - All sounds are from the following website: https://mixkit.co/free-sound-effects/game/
  - The background and terrain are from: https://opengameart.org/content/swamp-2d-tileset-pixel-art
  - The bat enemy is from: https://opengameart.org/content/castle-platformer
