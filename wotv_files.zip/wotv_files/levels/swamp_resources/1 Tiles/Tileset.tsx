<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Tileset" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="Tileset.png" width="320" height="192"/>
</tileset>
