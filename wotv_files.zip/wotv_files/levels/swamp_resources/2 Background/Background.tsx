<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Background" tilewidth="32" tileheight="32" tilecount="180" columns="18">
 <image source="Background.png" width="576" height="324"/>
</tileset>
