import pygame
from pygame import mixer
import os
import random
import csv
import sys
#import button
from settings import *
from sprites import *
from tilemap import *

#setup, initializing variables and screen
mixer.init()
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption(TITLE)
clock = pygame.time.Clock()
level = Level(LEVEL_MAP, screen)

#no game class atm, that can be added. most of the game logic is in tilemaps at this moment, could be moved back here
run = True
while run:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(RED)
    level.run()
    pygame.display.update()
    #clock.tick(FPS), but this slows down the game running so i dunno

#draw_bg can be added back in, but the background is in the tiled level data atm

#unused atm, here from the og code
def draw_text(text, font, text_col, pos):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

def draw_bg():
    pass

def reset_level():
    pass



    
